package kz.askar.datastorage3;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class PrefActivity extends AppCompatActivity {

    EditText nameET;
    TextView nameTV;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pref);

        nameET = (EditText)findViewById(R.id.nameET);
        nameTV = (TextView)findViewById(R.id.nameTV);
        sp = getSharedPreferences("e04spref", MODE_PRIVATE);
        nameTV.setText(sp.getString("name", ""));
    }

    public void save(View v){
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("name", nameET.getText().toString());
        editor.commit();
    }
}
