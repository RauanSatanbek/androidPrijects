package kz.askar.datastorage3;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PhonebookActivity extends AppCompatActivity {

    DBHelper dbh;
    SQLiteDatabase db;

    LinearLayout contactsLL;

    final int MENU_UPDATE = 1;
    final int MENU_DELETE = 2;

    long changableId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phonebook);

        dbh = new DBHelper(this);
        db = dbh.getWritableDatabase();

        contactsLL = (LinearLayout)findViewById(R.id.contactsLL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh(null);
    }

    public void createContact(View v){
        Intent i = new Intent(this, CreateActivity.class);
        i.putExtra("action", "insert");
        startActivity(i);
    }

    public void refresh(View v){
        contactsLL.removeAllViews();
        LinearLayout.LayoutParams llp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);

        Cursor c = db.query("contacts", null, null, null, null, null, "name");
        if(c.moveToFirst()){
            do{
                long id = c.getLong(c.getColumnIndex("_id"));
                String name = c.getString(c.getColumnIndex("name"));
                String phone = c.getString(c.getColumnIndex("phone"));

                TextView tv = new TextView(this);
                tv.setTextSize(25);
                tv.setText(id + "." + name + ":" + phone);
                contactsLL.addView(tv, llp);
                registerForContextMenu(tv);
            }while(c.moveToNext());
        }
        c.close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbh.close();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu,
                                    View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        String contactStr = ((TextView)v).getText().toString();
        changableId = Long.parseLong(contactStr.split("\\.")[0]);

        menu.add(0, MENU_UPDATE, 0, "Update");
        menu.add(0, MENU_DELETE, 0, "Delete");

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case MENU_UPDATE:
                Intent i = new Intent(this, CreateActivity.class);
                i.putExtra("action", "update");
                i.putExtra("id", changableId);
                startActivity(i);
                break;
            case MENU_DELETE:
                db.delete("contacts", "_id=?", new String[]{changableId+""});
                refresh(null);
                break;
        }
        return super.onContextItemSelected(item);
    }
}
