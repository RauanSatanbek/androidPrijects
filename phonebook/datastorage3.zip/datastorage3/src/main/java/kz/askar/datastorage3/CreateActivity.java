package kz.askar.datastorage3;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class CreateActivity extends AppCompatActivity {

    DBHelper dbh;
    SQLiteDatabase db;

    EditText nameET;
    EditText phoneET;

    String action;
    long changableId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        dbh = new DBHelper(this);
        db = dbh.getWritableDatabase();

        nameET = (EditText)findViewById(R.id.nameET);
        phoneET = (EditText)findViewById(R.id.phoneET);

        Intent intent = getIntent();
        action = intent.getStringExtra("action");
        if(action.equals("update")){
            changableId = intent.getLongExtra("id", 0);
            Cursor c = db.query("contacts", null, "_id=?",
                    new String[]{changableId+""}, null, null, null);
            if(c.moveToFirst()){
                nameET.setText(c.getString(c.getColumnIndex("name")));
                phoneET.setText(c.getString(c.getColumnIndex("phone")));
            }

        }

    }

    public void save(View v){
        ContentValues cv = new ContentValues();
        cv.put("name", nameET.getText().toString());
        cv.put("phone", phoneET.getText().toString());

        if(action.equals("insert")){
            db.insert("contacts", null, cv);
        }else if(action.equals("update")){
            db.update("contacts", cv, "_id="+changableId, null);
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbh.close();
    }
}
